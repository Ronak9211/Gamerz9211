// scripts.js - Add your JS here
console.log('Hello Gamerz9211');